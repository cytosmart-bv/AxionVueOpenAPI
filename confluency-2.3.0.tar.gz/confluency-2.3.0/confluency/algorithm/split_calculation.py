from math import ceil

import numpy as np

from .confluency import backgroundsubstractv2, MAX_ENTROPY
from .confluency import confluency as confluency_alg


def confluency(img, max_size=5000, disk_size=5):
    """
    Function split the image in smaller part of max_size*max_size. Apply the confuency to it and stitch them together.
    img: (numpy.ndarray dtype=uint8) the input image
    max_size (int): the size of the parts it is slicesed into. Set this higher to speed thing up BUT use more memory.

    == confluency parameters
    nois_var (float, int): the noise added to the image to make small noise inrelavant
    threshold (float, int): cutoff value. Higher this to increase specivicity but dicrease senitivity
    illum_paramter (int): The power of the illumination correction before. Increasing will make bigger details in the image to be analysed
    clossing (int): The amount of closing done at the end. Increase fill bigger holes at the end.
    Opening (int): The amount of opening done at the end. Increase it will delete bigger group of positive pixels.
    disk_size (int): The entropy filter size. Increasing will make the pixel take a bigger area around it in to account.
    """
    img = backgroundsubstractv2(img)
    # === splitting image for processing ===
    padding_size = 35
    num_x_slices = ceil(img.shape[0] / max_size)
    num_y_slices = ceil(img.shape[1] / max_size)

    if img.shape[0] % max_size < padding_size and img.shape[0] % max_size > 0:
        num_x_slices -= 1

    if img.shape[1] % max_size < padding_size and img.shape[1] % max_size > 0:
        num_y_slices -= 1

    width_slice = max_size
    height_slice = max_size

    result_img = np.zeros(np.shape(img), dtype=np.uint8)

    for num_x in range(num_x_slices):
        if num_x == 0:
            x_begin = num_x * width_slice
        else:
            x_begin = num_x * width_slice - padding_size
        x_stop = (num_x + 1) * width_slice + padding_size

        for num_y in range(num_y_slices):
            if num_y == 0:
                y_begin = num_y * height_slice
            else:
                y_begin = num_y * height_slice - padding_size
            y_stop = (num_y + 1) * height_slice + padding_size

            current_slice = img[x_begin:x_stop, y_begin:y_stop]
            conf_slice = confluency_alg(current_slice, disk_size)

            del current_slice
            s = np.shape(conf_slice)

            if num_x == 0:
                padding_x_start = 0
            else:
                padding_x_start = padding_size

            if num_x == num_x_slices - 1:
                padding_x_stop = 0
            else:
                padding_x_stop = padding_size

            if num_y == 0:
                padding_y_start = 0
            else:
                padding_y_start = padding_size

            if num_y == num_y_slices - 1:
                padding_y_stop = 0
            else:
                padding_y_stop = padding_size

            conf_slice = conf_slice[
                padding_x_start : s[0] - padding_x_stop,
                padding_y_start : s[1] - padding_y_stop,
            ]

            result_img[
                x_begin + padding_x_start : x_stop - padding_x_stop,
                y_begin + padding_y_start : y_stop - padding_y_stop,
            ] = conf_slice

            del conf_slice

    return result_img, MAX_ENTROPY

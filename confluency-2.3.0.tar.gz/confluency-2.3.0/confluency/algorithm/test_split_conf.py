import os

import numpy as np
from unittest import TestCase

from .confluency import confluency
from .split_calculation import confluency as split_conf

class TestSplit_conf(TestCase):

    def test_no_split(self):
        np.random.seed(92348)
        img = (np.random.random((400, 400)) * 255).astype(np.uint8)
        result1 = split_conf(img, 1000, disk_size=5)
        result2 = confluency(img, disk_size=5)
        thresholded_img = (result1[0] >= ((3.00/result1[1]))*255)
        thresholded_img2 = (result2 >= ((3.00/result1[1]))*255)
        np.testing.assert_array_almost_equal(thresholded_img, thresholded_img2, -1)

    def test_small_overflow(self):
        np.random.seed(92348)
        img = (np.random.random((405, 405)) * 255).astype(np.uint8)
        result1 = split_conf(img, 1000, disk_size=5)
        result2 = confluency(img, disk_size=5)
        thresholded_img = (result1[0] >= ((3.00/result1[1]))*255)
        thresholded_img2 = (result2 >= ((3.00/result1[1]))*255)
        np.testing.assert_array_almost_equal(thresholded_img, thresholded_img2, -1)

    def test_2_2_small_overflow(self):
        np.random.seed(92348)
        img = (np.random.random((805, 805)) * 255).astype(np.uint8)
        result1 = split_conf(img, 1000, disk_size=5)
        result2 = confluency(img, disk_size=5)
        thresholded_img = (result1[0] >= ((3.00/result1[1]))*255)
        thresholded_img2 = (result2 >= ((3.00/result1[1]))*255)
        np.testing.assert_array_almost_equal(thresholded_img, thresholded_img2, -1)

    def test_small_underflow(self):
        np.random.seed(92348)
        img = (np.random.random((395, 395)) * 255).astype(np.uint8)
        result1 = split_conf(img, 1000, disk_size=5)
        result2 = confluency(img, disk_size=5)
        thresholded_img = (result1[0] >= ((3.00/result1[1]))*255)
        thresholded_img2 = (result2 >= ((3.00/result1[1]))*255)
        np.testing.assert_array_almost_equal(thresholded_img, thresholded_img2, -1)

    def test_unequal_rect2(self):
        np.random.seed(92348)
        img = (np.random.random((700, 400)) * 255).astype(np.uint8)
        result1 = split_conf(img, 1000, disk_size=5)
        result2 = confluency(img, disk_size=5)
        thresholded_img = (result1[0] >= ((3.00/result1[1]))*255)
        thresholded_img2 = (result2 >= ((3.00/result1[1]))*255)
        np.testing.assert_array_almost_equal(thresholded_img, thresholded_img2, -1)

    def test_unequal_rect(self):
        np.random.seed(92348)
        img = (np.random.random((101, 101)) * 255).astype(np.uint8)
        result1 = split_conf(img, 1000, disk_size=5)
        result2 = confluency(img, disk_size=5)
        thresholded_img = (result1[0] >= ((3.00/result1[1]))*255)
        thresholded_img2 = (result2 >= ((3.00/result1[1]))*255)
        np.testing.assert_array_almost_equal(thresholded_img, thresholded_img2, -1)
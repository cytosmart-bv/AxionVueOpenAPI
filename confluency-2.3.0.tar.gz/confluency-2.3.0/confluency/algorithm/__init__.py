from .split_calculation import confluency as split_calculation
from .confluency import multi_image_to_histogram
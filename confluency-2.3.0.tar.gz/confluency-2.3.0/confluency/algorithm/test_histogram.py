import numpy as np
from unittest import TestCase

from .confluency import multi_image_to_histogram


class TestMultiImage2Histogram(TestCase):
    def test_mono_0_hist(self):
        multi_img = (np.ones((400, 400)) * 0).astype(np.uint8)
        result = multi_image_to_histogram(multi_img)
        result_expected = [1] * 1 + [0] * 255
        np.testing.assert_array_equal(result, result_expected)

    def test_mono_255_hist(self):
        multi_img = (np.ones((400, 400)) * 255).astype(np.uint8)
        result = multi_image_to_histogram(multi_img)
        result_expected = [1] * 256 + [0] * 0
        self.assertListEqual(result, result_expected)

    def test_mono_127_hist(self):
        multi_img = (np.ones((400, 400)) * 127).astype(np.uint8)
        result = multi_image_to_histogram(multi_img)
        result_expected = [1] * 128 + [0] * 128
        self.assertListEqual(result, result_expected)

    def test_diff_1_hist(self):
        multi_img = (np.ones((400, 400)) * 127).astype(np.uint8)
        multi_img[:200, :200] = 0
        multi_img[200:, 200:] = 255
        result = multi_image_to_histogram(multi_img)
        result_expected = [1] * 1 + [0.75] * 127 + [0.25] * 128
        self.assertListEqual(result, result_expected)

    def test_mask_hist(self):
        multi_img = (np.ones((400, 400)) * 127).astype(np.uint8)
        multi_img[:200, :200] = 0
        multi_img[200:, 200:] = 255

        mask = np.zeros((400, 400), dtype=np.uint8)
        mask[:, 200:] = 1

        result = multi_image_to_histogram(multi_img, mask=mask)
        result_expected = [1] * 128 + [0.5] * 128
        self.assertListEqual(result, result_expected)

    def test_mask_hist_with_zeros(self):
        multi_img = (np.ones((400, 400)) * 127).astype(np.uint8)
        multi_img[:200, :200] = 0
        multi_img[200:, 200:] = 255

        mask = np.zeros((400, 400), dtype=np.uint8)
        mask[:, :200] = 1

        result = multi_image_to_histogram(multi_img, mask=mask)
        result_expected = [1] * 1 + [0.5] * 127 + [0] * 128
        self.assertListEqual(result, result_expected)

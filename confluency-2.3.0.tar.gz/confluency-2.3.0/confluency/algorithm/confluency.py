import cv2
import numpy as np
from skimage.filters.rank import entropy
from skimage.morphology import disk

MAX_ENTROPY = 8


def reject_outliers(data, m=2):
    return data[abs(data - np.mean(data)) < m * np.std(data, dtype=np.float64)]


def backgroundsubstractv2(img):
    img = np.int16(img)
    gb = cv2.GaussianBlur(img, (301, 301), 0)
    gb = np.int16(gb)
    img = np.divide(img, gb, dtype=np.float16)
    np.nan_to_num(img, copy=False)
    imgmax = reject_outliers(img, m=2)
    img = np.clip(img, 0, np.max(imgmax))
    img = (img / np.max(imgmax)) * 255

    return img.astype(np.uint8)


def confluency(input_img, disk_size):
    # Calculate entropy
    result_np = entropy(np.array(input_img).astype(np.uint8), disk(disk_size))
    # Normalize results
    result_np = (result_np / MAX_ENTROPY) * 255
    result_np = np.clip(result_np, 0, 255)
    return result_np.astype(np.uint8)


def thresholdedmultiimg(multiconf_img, thresholdvalue):
    thresholded_img = (multiconf_img >= thresholdvalue) * 255
    return thresholded_img


def multi_image_to_histogram(multi_img, mask=None):
    # Set everything outside the mask to -1
    # So it will be ignored by the 0-255 histogram
    if mask is not None:
        multi_img *= mask

    # Make the normalized histogram
    histr, _ = np.histogram(multi_img, bins=255, range=[1, 256])
    if mask is None:
        histr = histr / multi_img.size
    else:
        histr = histr / np.sum(mask)
    np.nan_to_num(histr, copy=False)
    histr = np.concatenate([[1-np.sum(histr)], histr])

    # We want a reverse cumsum so we flip, cumsum, flip
    conf_dict = np.cumsum(np.flip(histr))
    conf_dict = np.round(conf_dict, 3)
    conf_dict = np.flip(conf_dict)

    return list(conf_dict)

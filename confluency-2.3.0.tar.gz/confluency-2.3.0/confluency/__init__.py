__author__ = """Tom Nijhof"""
__email__ = "tom.nijhof@cytosmart.com"
__version__ = "2.3.0"

from .main import Confluency as confluency
from .main import Confluency

from typing import Tuple, Union
import cv2
import numpy as np

from .algorithm import split_calculation, multi_image_to_histogram


class Confluency:
    def __init__(self, split_size: int):
        """
        This package calculates the confluency of a well image that is given to it.
        Code can be ran by just calling .calculate or calling all functions separately.

        split_size: is the area that gets calculated at once.
            Bigger split_size means more at the same time and higher speed but also higher memory usage
        """
        self.split_size = split_size

    def make_binary(self, im, threshold):
        pixel_threshold = threshold * 255
        _, bin_im = cv2.threshold(np.array(im), pixel_threshold, 255, cv2.THRESH_BINARY)

        return bin_im

    def calculate_coverage(self, bin_im,  mask: Union[np.ndarray, None] = None):
        non_zeros = cv2.countNonZero(bin_im * mask)
        conf_num = non_zeros / np.sum(mask) * 100

        return conf_num

    def calculate_histogram(self, multi_img: np.ndarray,  mask: Union[np.ndarray, None] = None) -> list:
        """Create single confluency number with different threshold

        Args:
            multi_img (np.ndarray): The multi image result of calculate()
            mask (Union[np.ndarray, None], optional): The mask that is applied.
                If a mask is given 1 means everyting WITHIN the mask is True
                Defaults to None.

        Returns:
            List: 256 confluency values for the different threshold from 0 till 255
        """        
        conf_dict = multi_image_to_histogram(multi_img, mask=mask)

        return conf_dict

    def generate_multi_img(self, img, disk_size=5):
        multi_img, default_threshold = split_calculation(
            img, self.split_size, disk_size
        )
        normalized_threshold = default_threshold / 255

        return multi_img, normalized_threshold

    def calculate(
        self, img: np.ndarray, mask: Union[np.ndarray, None] = None
    ) -> Tuple[np.ndarray, np.ndarray, float]:
        """Calculate confluency over the image.
        Applies mask to results

        Args:
            img (np.ndarray): uint8 image
            mask (np.ndarray or None, optional): 0 or 1 mask for the ROI, if None everything is ROI. Defaults to None.

        Returns:
            multi_img (np.ndarray): multi image result
            bin_img (np.ndarray): binary image result
            confluency_percentage (float): confluency number of binary image
        """
        if mask is None:
            mask = np.ones_like(img)

        assert np.max(mask) <= 1 and np.min(mask) >= 0

        multi_img, normalized_threshold = self.generate_multi_img(img)
        multi_img *= mask
        bin_img = self.make_binary(multi_img, normalized_threshold)
        confluency_percentage = self.calculate_coverage(bin_img, mask)

        return multi_img, bin_img, confluency_percentage

History
=======
2.3.0 (2022-02-04)
Add mask as acceptable input

2.2.8 (2021-10-08)
BUGFIX: calculate was broken

2.2.7 (2021-08-18)
BUGFIX: backgroundsubstractv2: Std could become inf
BUGFIX: backgroundsubstractv2: Remove outliers

2.2.6 (2021-06-30)
Make requirment of opencv a range not fixed

2.2.5
Remove unused parameters
Replace dtypes with minimum memory usages once

2.2.4
Removed 100 values to 256 values in image to histogram

2.1.0 2020-march-25
Added .calculate in main to make it backwards compatible but also still working
with old structure. And some clean up.

1.0.0 2019-july-01
Migrating the current confluency solution to package.
The functions split the image in to multiple smaller areas to analysis. 
After that is cuts off an area it is uncurrent about and stitches everything back together to get one big result.

Analysing itself:
- First the image is normalized with illumation correction
- An entropy filter is applied followed by a threshold
- This image is rounded by closing followed by opening
- The result of this is outputed
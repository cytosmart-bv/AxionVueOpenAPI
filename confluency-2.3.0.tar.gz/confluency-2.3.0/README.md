confluency
=====

confluency is used the calculate cell surface of a brightfield image.

## Getting confluency

``` cmd
pip install confluency
```

## License

confluency is free for academic and educational use.

For commercial use please contact [CytoSMART](https://cytosmart.com/contact).

## Features

* Calculate: multi threshold confluency
  * add binary mask
* calculate_histogram: Create single confluency number with different threshold
* calculate_coverage: Calculate single confluency number of a binary image
  * add binary mask
* make_binary: Turn multi image into binary image using threshold